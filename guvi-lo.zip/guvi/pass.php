<?php
include('config.php'); // Include your database configuration file

if (isset($_POST['resetEmail']) && isset($_POST['newPassword'])) {
    $resetEmail = $_POST['resetEmail'];
    $newPassword = $_POST['newPassword']; // Hash the new password for security

    // Check if the user with the given email exists
    $check_query = "SELECT * FROM sign WHERE email = '$resetEmail'";
    $result = mysqli_query($db, $check_query);

    if (mysqli_num_rows($result) > 0) {
        // Update the password for the user with the given email
        $update_query = "UPDATE sign SET pass = '$newPassword' WHERE email = '$resetEmail'";

        if (mysqli_query($db, $update_query)) {
            $response = array('status' => 200, 'message' => 'Password updated successfully');
        } else {
            $response = array('status' => 500, 'message' => 'Password update failed: ' . mysqli_error($db));
        }
    } else {
        $response = array('status' => 404, 'message' => 'User not found with the provided email');
    }

    echo json_encode($response);
}
?>
