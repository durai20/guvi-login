<?php
include('config.php'); // Include your database configuration file

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_signup'])) {
    $name = $_POST['name'];
    $gender = $_POST['gender']; // Get the selected gender value
    $email = $_POST['emailid'];
    $dob = $_POST['dob'];
    $phone = $_POST['phone'];
    $password = $_POST['pass']; // Hash the password for security

    // Hash the password
    

    // Create an INSERT query
    $insert_query = "INSERT INTO sign (name, gender, email, dob, phone, pass) VALUES ('$name', '$gender', '$email', '$dob', '$phone', '$password')";

    if (mysqli_query($db, $insert_query)) {
        $response = [   
            'status' => 200,
            'message' => 'Registration Successful'
        ];
        echo json_encode($response);
    } else {
        $response = [
            'status' => 500,
            'message' => 'Error occurred during registration'
        ];
        echo json_encode($response);
    }
}
?>
