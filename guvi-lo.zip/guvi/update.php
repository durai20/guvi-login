<?php
require 'config.php';
include("session.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $dob = mysqli_real_escape_string($db, $_POST['dob']);
    $name = mysqli_real_escape_string($db, $_POST['name']);
    $age = mysqli_real_escape_string($db, $_POST['age']);
    $phone = mysqli_real_escape_string($db, $_POST['phone']);
    $gender = mysqli_real_escape_string($db, $_POST['gender']);
    $address = mysqli_real_escape_string($db, $_POST['address']);

    // Check if a new profile picture has been uploaded
    if (isset($_FILES['profilePicture'])) {
        $targetDirectory = "assets/images/profiole-image/"; // Specify the directory where you want to store profile pictures
        $targetFileName = $targetDirectory . basename($_FILES['profilePicture']['name']);
        
        // Check if the file was successfully uploaded
        if (move_uploaded_file($_FILES['profilePicture']['tmp_name'], $targetFileName)) {
            // Update the user's profile picture path in the database
            $query = "UPDATE sign SET name='$name', age='$age', dob='$dob', phone='$phone', address='$address', gender='$gender', photo='$targetFileName' WHERE email='$s'";
        } else {
            $res = [
                'status' => 500,
                'message' => 'Failed to Upload Profile Picture'
            ];
            echo json_encode($res);
            return;
        }
    } else {
        // No new profile picture uploaded, update other fields only
        $query = "UPDATE sign SET name='$name', age='$age', dob='$dob', phone='$phone', address='$address', gender='$gender' WHERE email='$s'";
    }

    $query_run = mysqli_query($db, $query);

    if ($query_run) {
        $res = [
            'status' => 200,
            'message' => 'Profile Updated Successfully'
        ];
        echo json_encode($res);
        return;
    } else {
        $res = [
            'status' => 500,
            'message' => 'Failed to Update Profile'
        ];
        echo json_encode($res);
        return;
    }
} else {
    $res = [
        'status' => 500,
        'message' => 'Failed to Update Profile'
    ];
    echo json_encode($res);
}
?>
