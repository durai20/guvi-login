$(document).ready(function () {
    $("#loginButton").click(function () {
        var email = $("#email").val();
        var password = $("#pass").val();

        $.ajax({
            type: "POST",
            url: "login.php", // Update the path based on your directory structure
            data: {
                email: email,
                password: password
            },
            success: function (response) {
                if (response === "success") {
                    $("#message").html("Login Successful");
                    window.location.href = ""; // Redirect on success
                } else if (response === "wrong"){
                    $("#message").html("Invalid Login Credentials");
                    window.location.href = "main.html";
                }
            },
            error: function () {
                $("#message").html("An error occurred during login.");
            }
        });
    });
});
