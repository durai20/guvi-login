<!DOCTYPE html>
<html lang="en">
<head>
	<title>Guvi Login</title>
	<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/11.4.24/sweetalert2.all.js"></script>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->	
	<link rel="icon" type="image/png" href="images/icons/favicon.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
<!--===============================================================================================-->
<style>
	#exampleModalLabel {
  text-align: center;
  margin: auto;
}

</style>
</head>
<body>
	
	<div class="limiter">
		<div class="container-login100">
			<div class="wrap-login100">
				<div class="login100-pic js-tilt" data-tilt>
					<img src="images/img-01.jpg" alt="IMG">
				</div>

				<form class="login100-form validate-form" id="loginform">
					<span class="login100-form-title">
						 Login
					</span>

					<div class="wrap-input100 validate-input" data-validate = "Valid email is required: ex@abc.xyz">
						<input class="input100" type="text" id="email" name="email" placeholder="Email">
						<span class="focus-input100"></span>
						<span class="symbol-input100">
							<i class="fa fa-envelope" aria-hidden="true"></i>
						</span>
					</div>

					<div class="wrap-input100 validate-input" data-validate = "Password is required">
						<input class="input100" type="password" id="pass1"  placeholder="Password">
						<span class="focus-input100"></span>
						<span class="symbol-input100">
							<i class="fa fa-lock" aria-hidden="true"></i>
						</span>
					</div>
					
					<div class="container-login100-form-btn">
						<button class="login100-form-btn" type="submit" name="loginbutton" id="loginbutton">
							Login
						</button>
					</div>

					<div class="text-center p-t-12">
    		
        			<a class="txt1" href="#" data-toggle="modal" data-target="#resetPasswordModal">Forgot Password?
					<i class="fa fa-long-arrow-right m-l-5" aria-hidden="true"></i>
					</a>
					
    				
					</div>

					<div class="text-center p-t-136">
								<a class="txt2" href="#" data-toggle="modal" data-target="#mod1">
									Create your Account
									<i class="fa fa-long-arrow-right m-l-5" aria-hidden="true"></i>
								</a>
						</div>

				</form>
			</div>
		</div>
	</div>
	<div class="tab-pane p-20" id="resetPassword" role="tabpanel">
   <div class="modal fade" id="resetPasswordModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
   <div class="modal-dialog">
   <div class="modal-content">
   <div class="modal-header">
      <h5 class="modal-title" id="exampleModalLabel">Reset Password</h5>
   </div>
   <form id="resetPasswordForm">
      <div class="modal-body">
	  <div class="mb-3">
            <label for="resetEmail">Email*</label>
            <input type="email" id="resetEmail" class="form-control" required>
         </div>
         <div class="mb-3">
            <label for="newPassword">New Password*</label>
            <input type="password" id="newPassword" class="form-control" required>
         </div>
		 <div class="mb-3">
            <label for="confirmPassword">Confirm Password*</label>
            <input type="password" id="confirmPassword" class="form-control" required>
         </div>
      </div>
      <div class="modal-footer">
         <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
         <button type="submit" class="btn btn-primary">Reset Password</button>
      </div>
   </form>
</div></div>
   </div>
</div>
	<div class="tab-pane p-20" id="messages" role="tabpanel">
				<div class="modal fade" id="mod1" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
					<div class="modal-dialog">
						<div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="exampleModalLabel" >SIGN UP</h5>
                                </div>
                                <form id="cform">
                                    <div class="modal-body">

                                        <div id="errorMessage" class="alert alert-warning d-none"></div>

                                        <div class="mb-3">
                                                <label for="">Name *</label>
                                            <input type="text"  id="name" class="form-control" required/>
                                        </div>
                                        <div class="mb-3">
                                        
										<div class="mb-3">
                                                <label for="">Email*</label>
                                            <input type="text"  id="emailid" class="form-control" required/>
                                        </div>
										<div class="mb-3">
                                                <label for="">Date of Birth*</label>
                                            <input type="date"  id="dob" class="form-control" required/>
                                        </div>
                                        <div class="mb-3">
                            <label for="">Gender *</label>
                            <select id="gender" class="form-control" required>
                                <option value="" disabled selected>Select your gender</option>
                                <option value="Male">Male</option>
                                <option value="female">Female</option>
                                <option value="other">Other</option>
                            </select>
                        </div>
                                        
                                        
										<div class="mb-3">
                                                <label for="">contact no*</label>
                                            <input type="number"  id="phone" class="form-control" required/>
                                            <div id="phoneError" class="text-danger"></div>
                                        </div> 
										<div class="mb-3">
                                                <label for="">PassWord*</label>
                                            	<input type="password"  id="pass" class="form-control" required/>
                                        </div> 
										   

                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                            <button type="submit" name="cform" id="cform"class=" cform btn btn-primary">SIGN UP</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                    </div>
    </div>
</div>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/11.4.24/sweetalert2.all.js"></script>
	<script>
$(document).ready(function() {
    $("#loginform").submit(function(e) {
        e.preventDefault();
        
        var email = $("#email").val();
        var password = $("#pass1").val();

        $.ajax({
            type: "POST",
            url: "login.php", // Update the path based on your directory structure
            data: {
                email: email,
                password: password
            },
            success: function(response) {
                response = JSON.parse(response); // Parse the JSON response

                if (response.status === 200) {
                    Swal.fire({
                        icon: 'success',
                        title: 'Success',
                        text: 'Login Successful'
                    }).then(function() {
                        window.location = "profile.php";
                    });
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: 'Invalid email or password. '
                    });
                }
            },
            error: function() {
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: 'An error occurred during login.'
                });
            }
        });
    });
});

$(document).ready(function() {
    $("#cform").submit(function(e) {
        e.preventDefault();
		console.log("Caked");
        var name = $("#name").val();
        var gender = $("#gender").val();
        var email = $("#emailid").val();
        var dob = $("#dob").val();
        var phone = $("#phone").val();
        var password = $("#pass").val();
        var PhoneNumberLength = 10; 

        // Check if the phone number meets the constraints
        if (phone.length < PhoneNumberLength || phone.length > PhoneNumberLength) {
            // Display an error message or handle the validation as needed
            $('#phoneError').text('Phone number must be of 10 numbers');
            return; // Prevent form submission if validation fails
        }
        else {
            // Clear the error message if validation passes
            $('#phoneError').text('');
        }


        $.ajax({
			
            type: "POST",
            url: "signup.php", // Update the path based on your directory structure
            data: {
                save_signup: true,
                name: name,
                gender : gender,
                emailid: email,
                dob: dob,
                phone: phone,
                pass: password
            },
            success: function(response) {
                response = JSON.parse(response);

                if (response.status == 200) {
                    // Registration successful
                    Swal.fire({
                        icon: 'success',
                        title: 'Success',
                        text: 'Registration Successful'
                    }).then(function() {
                        // Optionally, redirect to another page after successful registration
                        window.location = "index.php";
                    });
                } else {
                    // Registration failed
                    Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: 'Registration Failed: ' + response.message
                    });
                }
            },
            error: function() {
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: 'An error occurred during registration.'
                });
            }
        });
    });
});


$(document).ready(function() {
   $("#resetPasswordForm").submit(function(e) {
      e.preventDefault();
		console.log("Cale")
      var newPassword = $("#newPassword").val();
      var confirmPassword = $("#confirmPassword").val();

      if (newPassword !== confirmPassword) {
         $("#errorMessage").removeClass("d-none");
         $("#errorMessage").text("Passwords do not match.");
         return;
      }

      var resetEmail = $("#resetEmail").val(); // Get the email entered in the form

      $.ajax({
         type: "POST",
         url: "pass.php", // Replace with the actual URL for resetting password
         data: {
            resetEmail: resetEmail,
            newPassword: newPassword
         },
         success: function(response) {
            response = JSON.parse(response);

            if (response.status === 200) {
               Swal.fire({
                  icon: 'success',
                  title: 'Success',
                  text: 'Password reset successful'
               }).then(function() {
                  // Close the reset password modal
                  $("#resetPasswordModal").modal("hide");
               });
            } else {
               $("#errorMessage").removeClass("d-none");
               $("#errorMessage").text(response.message);
            }
         },
         error: function() {
            $("#errorMessage").removeClass("d-none");
            $("#errorMessage").text("An error occurred during password reset.");
         }
      });
   });
});




</script>

	


<!--===============================================================================================-->	
<!--===============================================================================================-->
	<script src="vendor/bootstrap/js/popper.js"></script>
	<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/tilt/tilt.jquery.min.js"></script>
	<script >
		$('.js-tilt').tilt({
			scale: 1.1
		})
	</script>
<!--===============================================================================================-->
	<script src="js/main.js"></script>

</body>
</html>